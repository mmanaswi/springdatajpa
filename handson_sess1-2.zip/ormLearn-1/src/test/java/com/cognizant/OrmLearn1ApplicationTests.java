package com.cognizant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrmLearn1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
