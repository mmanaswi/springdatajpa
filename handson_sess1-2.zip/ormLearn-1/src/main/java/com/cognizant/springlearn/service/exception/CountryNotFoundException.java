package com.cognizant.springlearn.service.exception;

@SuppressWarnings("serial")
public class CountryNotFoundException extends Exception{

	public CountryNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public CountryNotFoundException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}
}
