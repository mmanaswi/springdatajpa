package com.cognizant.moviecuriser.service.exception;
/**
 * 
 * @author Danish
 *
 */
public class MovieNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
