package com.cognizant.springlearn.service.exception;

@SuppressWarnings("serial")
public class EmployeeNotFoundException extends Exception{

	public EmployeeNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public EmployeeNotFoundException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}
}
